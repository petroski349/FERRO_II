public class Acervo {

    private List<CD> cd;

    public Acervo() {
        this.cd = null;
    }

    void addCD(CD cd){
        boolean x = false;
        for(CD i: this.cd)
            if(i == cd)
                x=true;
        if(x=false)
            cd.add(cd);
    }

    public List<CD> getCd() {
        return cd;
    }
}
