public class Musica {

    private String nome;
    private int tempo;


    public Musica(String nome,int tempo){
        this.nome = nome;
        this.tempo = tempo;
    }

    public String getNome() {
        return nome;
    }

    public int getTempo() {
        return tempo;
    }
}
